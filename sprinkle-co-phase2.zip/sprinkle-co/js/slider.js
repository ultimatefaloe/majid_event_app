/* ============================================================
   SLIDER.JS
   Concept demonstrated: a small reusable class instead of
   copy-pasting slider logic for the hero banner AND the
   testimonials carousel. Both are just different instances of
   the same Slider class, configured with different containers.
   ============================================================ */

class Slider {
  /**
   * @param {string} rootSelector - wraps the whole slider component
   * @param {object} options
   * @param {boolean} options.autoplay
   * @param {number} options.interval - ms between auto-advances
   */
  constructor(rootSelector, options = {}) {
    this.root = document.querySelector(rootSelector);
    if (!this.root) return;

    this.track = this.root.querySelector('.slider-track');
    this.slides = [...this.root.querySelectorAll('.slide')];
    this.prevBtn = this.root.querySelector('.slider-prev');
    this.nextBtn = this.root.querySelector('.slider-next');
    this.dotsContainer = this.root.querySelector('.slider-dots');

    this.index = 0;
    this.autoplay = options.autoplay ?? false;
    this.interval = options.interval ?? 5000;
    this.timer = null;

    this.buildDots();
    this.bindEvents();
    this.goTo(0);
    if (this.autoplay) this.startAutoplay();
  }

  buildDots() {
    if (!this.dotsContainer) return;
    this.dotsContainer.innerHTML = this.slides
      .map((_, i) => `<button class="slider-dot" aria-label="Go to slide ${i + 1}" data-index="${i}"></button>`)
      .join('');
    this.dots = [...this.dotsContainer.querySelectorAll('.slider-dot')];
    this.dots.forEach(dot => {
      dot.addEventListener('click', () => this.goTo(Number(dot.dataset.index)));
    });
  }

  bindEvents() {
    if (this.prevBtn) this.prevBtn.addEventListener('click', () => this.prev());
    if (this.nextBtn) this.nextBtn.addEventListener('click', () => this.next());

    // Pause autoplay while the user's mouse is over the slider — avoids
    // yanking a testimonial away mid-read.
    this.root.addEventListener('mouseenter', () => this.stopAutoplay());
    this.root.addEventListener('mouseleave', () => { if (this.autoplay) this.startAutoplay(); });

    // Basic swipe support for touch devices
    let startX = 0;
    this.root.addEventListener('touchstart', e => { startX = e.touches[0].clientX; }, { passive: true });
    this.root.addEventListener('touchend', e => {
      const delta = e.changedTouches[0].clientX - startX;
      if (delta > 40) this.prev();
      else if (delta < -40) this.next();
    }, { passive: true });
  }

  goTo(i) {
    this.index = (i + this.slides.length) % this.slides.length;
    this.track.style.transform = `translateX(-${this.index * 100}%)`;
    if (this.dots) {
      this.dots.forEach((dot, di) => dot.classList.toggle('active', di === this.index));
    }
  }

  next() { this.goTo(this.index + 1); }
  prev() { this.goTo(this.index - 1); }

  startAutoplay() {
    this.stopAutoplay();
    this.timer = setInterval(() => this.next(), this.interval);
  }
  stopAutoplay() {
    if (this.timer) clearInterval(this.timer);
  }
}
