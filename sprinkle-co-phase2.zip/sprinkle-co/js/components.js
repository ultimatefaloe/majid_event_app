/* ============================================================
   COMPONENTS.JS
   Concept demonstrated: DOM injection of shared markup.
   Why: this is a plain multi-page site (no framework, no build
   step), so instead of pasting the same <header> and <footer>
   into every .html file — and having them drift out of sync —
   each page has an empty <div id="site-header"></div> and
   <div id="site-footer"></div>, and this script fills them in
   on load. One place to edit the nav; every page updates.
   ============================================================ */

/* ---------- Small inline icon set (no external icon library) ---------- */
const ICONS = {
  search: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  heart: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21s-7.5-4.6-10-9.3C.3 8 2 4.5 5.6 4a5 5 0 0 1 6.4 2 5 5 0 0 1 6.4-2c3.6.5 5.3 4 3.6 7.7C19.5 16.4 12 21 12 21z"/></svg>`,
  bag: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 8h12l-1 12H7L6 8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg>`,
  user: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 5-6 8-6s6.5 2 8 6"/></svg>`,
  cake: `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18v-6a3 3 0 0 0-3-3H6a3 3 0 0 0-3 3v6z"/><path d="M12 12V7"/><circle cx="12" cy="4.5" r="1.5"/><path d="M3 17h18"/></svg>`,
  arrowUp: `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>`,
};

const NAV_LINKS = [
  { label: 'Home', href: 'index.html' },
  { label: 'Shop', href: 'shop.html' },
  { label: 'Categories', href: 'categories.html' },
  { label: 'About', href: 'about.html' },
  { label: 'Contact', href: 'contact.html' },
  { label: 'FAQ', href: 'faq.html' },
];

/** Reads the current page filename so the nav can mark it active. */
function currentPage() {
  const path = window.location.pathname.split('/').pop();
  return path === '' ? 'index.html' : path;
}

function renderHeader() {
  const target = document.getElementById('site-header');
  if (!target) return;
  const active = currentPage();

  const links = NAV_LINKS.map(link => {
    const isActive = link.href === active;
    return `<a href="${link.href}" ${isActive ? 'aria-current="page"' : ''}>${link.label}</a>`;
  }).join('');

  target.innerHTML = `
    <div class="navbar container">
      <a href="index.html" class="nav-logo">
        <span aria-hidden="true">${ICONS.cake}</span>
        Sprinkle &amp; Co.
      </a>

      <nav class="nav-links" id="nav-links" aria-label="Primary">
        ${links}
      </nav>

      <div class="nav-actions">
        <button class="btn-icon hide-mobile" id="search-toggle" aria-label="Search products">
          ${ICONS.search}
        </button>
        <a href="wishlist.html" class="btn-icon" aria-label="Wishlist">
          ${ICONS.heart}
          <span class="badge-count" id="wishlist-count" hidden>0</span>
        </a>
        <a href="cart.html" class="btn-icon" aria-label="Shopping cart">
          ${ICONS.bag}
          <span class="badge-count" id="cart-count" hidden>0</span>
        </a>
        <a href="login.html" class="btn-icon hide-mobile" aria-label="Account">
          ${ICONS.user}
        </a>
        <button class="nav-toggle" id="nav-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="nav-links">
          <span></span>
        </button>
      </div>
    </div>
  `;

  wireNavToggle();
}

function wireNavToggle() {
  const toggle = document.getElementById('nav-toggle');
  const links = document.getElementById('nav-links');
  if (!toggle || !links) return;

  toggle.addEventListener('click', () => {
    const isOpen = links.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(isOpen));
    toggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
  });

  // Close the mobile menu after a link is chosen, so navigating feels immediate.
  links.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      links.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    });
  });
}

function renderFooter() {
  const target = document.getElementById('site-footer');
  if (!target) return;

  target.innerHTML = `
    <div class="container">
      <div class="footer-grid">
        <div>
          <div class="footer-brand">Sprinkle &amp; Co.</div>
          <p class="footer-tagline">Small-batch cakes and treats, baked for birthdays, first days, and any day that needs one.</p>
        </div>
        <div class="footer-col">
          <h4>Shop</h4>
          <ul>
            <li><a href="shop.html">All treats</a></li>
            <li><a href="categories.html">Categories</a></li>
            <li><a href="shop.html#new">New arrivals</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Support</h4>
          <ul>
            <li><a href="faq.html">FAQ</a></li>
            <li><a href="contact.html">Contact us</a></li>
            <li><a href="checkout.html">Order tracking</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h4>Stay in touch</h4>
          <p class="text-sm mb-3" style="color:#C9B8AD;">Get new-flavor drops and weekend specials.</p>
          <form class="flex gap-2" id="newsletter-form">
            <label for="newsletter-email" class="visually-hidden">Email address</label>
            <input type="email" id="newsletter-email" placeholder="you@example.com" required
              style="flex:1; padding:10px 14px; border-radius:999px; border:none; font-size: var(--fs-sm);">
            <button type="submit" class="btn btn-primary" style="padding:10px 18px;">Join</button>
          </form>
        </div>
      </div>

      <div class="footer-bottom">
        <span>&copy; <span id="footer-year"></span> Sprinkle &amp; Co. — an educational demo project.</span>
        <div class="footer-social">
          <a href="#" aria-label="Instagram">IG</a>
          <a href="#" aria-label="TikTok">TT</a>
          <a href="#" aria-label="Pinterest">PT</a>
        </div>
      </div>
    </div>
  `;

  const yearEl = document.getElementById('footer-year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const newsletterForm = document.getElementById('newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', e => {
      e.preventDefault();
      showToast("You're on the list! 🎂");
      newsletterForm.reset();
    });
  }
}

/* ============================================================
   BACK TO TOP
   ============================================================ */
function initBackToTop() {
  const btn = document.createElement('button');
  btn.className = 'back-to-top';
  btn.setAttribute('aria-label', 'Back to top');
  btn.innerHTML = ICONS.arrowUp;
  document.body.appendChild(btn);

  window.addEventListener('scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 500);
  });
  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/* ============================================================
   TOAST NOTIFICATIONS
   Concept demonstrated: dynamically creating, then removing,
   DOM nodes on a timer — used across cart/wishlist/forms.
   ============================================================ */
function showToast(message) {
  let stack = document.querySelector('.toast-stack');
  if (!stack) {
    stack = document.createElement('div');
    stack.className = 'toast-stack';
    document.body.appendChild(stack);
  }
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  stack.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('leaving');
    toast.addEventListener('animationend', () => toast.remove());
  }, 2600);
}

document.addEventListener('DOMContentLoaded', () => {
  renderHeader();
  renderFooter();
  initBackToTop();
});
