/* ============================================================
   APP.JS
   Concept demonstrated: a single entry point that feature-detects
   which page it's on (by checking for elements in the DOM) rather
   than every page needing a bespoke <script> list. Keeps the
   <script> tags identical across all 11 HTML pages.
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  // ---- Home page ----
  if (document.getElementById('hero-slider')) {
    new Slider('#hero-slider', { autoplay: true, interval: 6000 });
  }
  if (document.getElementById('testimonial-slider')) {
    new Slider('#testimonial-slider', { autoplay: true, interval: 7000 });
  }
  if (document.getElementById('featured-products')) {
    loadFeaturedProducts();
  }

  // Delegated listener for "Add to cart" — works for any product card
  // rendered now or later, since the listener lives on the document.
  document.addEventListener('click', e => {
    const addBtn = e.target.closest('[data-add-to-cart]');
    if (addBtn) {
      showToast('Added to cart 🛒');
    }
    const wishBtn = e.target.closest('[data-wishlist-id]');
    if (wishBtn) {
      wishBtn.classList.toggle('active');
      wishBtn.textContent = wishBtn.classList.contains('active') ? '♥' : '♡';
      showToast(wishBtn.classList.contains('active') ? 'Added to wishlist 💗' : 'Removed from wishlist');
    }
  });
});
