/* ============================================================
   STORAGE.JS
   Concept demonstrated: wrapping localStorage in small helper
   functions with error handling and JSON parsing built in, so
   every later module (cart.js, wishlist.js) reads/writes data
   the same safe way instead of repeating try/catch everywhere.
   ============================================================ */

const Storage = {
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (err) {
      console.error(`Storage.get failed for "${key}"`, err);
      return fallback;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (err) {
      console.error(`Storage.set failed for "${key}"`, err);
      return false;
    }
  },
  remove(key) {
    localStorage.removeItem(key);
  },
};
