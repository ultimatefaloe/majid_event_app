/* ============================================================
   PRODUCTS.JS
   Concept demonstrated: fetch() + async/await to load data from
   a JSON file, then build DOM nodes from it instead of hardcoding
   repeated product HTML. Run this project from a local server
   (e.g. `npx serve .`) rather than double-clicking index.html —
   fetch() of local files is blocked under the file:// protocol
   by browser security rules.
   ============================================================ */

/** Fetches and caches products.json for the lifetime of the page. */
let productsCache = null;
async function loadProducts() {
  if (productsCache) return productsCache;
  try {
    const res = await fetch('data/products.json');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    productsCache = await res.json();
    return productsCache;
  } catch (err) {
    console.error('Failed to load products.json', err);
    return [];
  }
}

function formatPrice(value) {
  return `$${value.toFixed(2)}`;
}

/** Builds a single product card's HTML. Reused by home, shop, and search results. */
function productCardTemplate(product) {
  const onSale = product.salePrice !== null && product.salePrice !== undefined;
  const priceMarkup = onSale
    ? `<span class="price-sale">${formatPrice(product.salePrice)}</span> <span class="price-was">${formatPrice(product.price)}</span>`
    : `<span>${formatPrice(product.price)}</span>`;

  return `
    <article class="product-card" data-id="${product.id}">
      ${product.badge ? `<span class="product-badge">${product.badge}</span>` : ''}
      <button class="product-wishlist-btn" data-wishlist-id="${product.id}" aria-label="Add ${product.name} to wishlist">♡</button>
      <a href="product.html?id=${product.id}" class="product-thumb" style="background:${product.color};">
        <span aria-hidden="true">${product.emoji}</span>
      </a>
      <div class="product-info">
        <a href="product.html?id=${product.id}" class="product-name">${product.name}</a>
        <div class="product-rating" aria-label="Rated ${product.rating} out of 5">
          ${'★'.repeat(Math.round(product.rating))}${'☆'.repeat(5 - Math.round(product.rating))}
          <span class="product-reviews">(${product.reviews})</span>
        </div>
        <div class="product-price">${priceMarkup}</div>
        <button class="btn btn-primary w-full mt-3" data-add-to-cart="${product.id}">Add to cart</button>
      </div>
    </article>
  `;
}

/** Renders a list of products into a container by id. */
function renderProductGrid(products, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;
  if (products.length === 0) {
    container.innerHTML = `<p class="text-muted text-center">No treats found. Try a different search or filter.</p>`;
    return;
  }
  container.innerHTML = products.map(productCardTemplate).join('');
}

/** Home page: show a curated handful of products, badge-first, then by rating. */
async function loadFeaturedProducts() {
  const container = document.getElementById('featured-products');
  if (!container) return;

  container.innerHTML = `<div class="spinner" role="status" aria-label="Loading products"></div>`;
  const products = await loadProducts();
  const featured = [...products]
    .sort((a, b) => (b.badge ? 1 : 0) - (a.badge ? 1 : 0) || b.rating - a.rating)
    .slice(0, 4);

  renderProductGrid(featured, 'featured-products');
}
